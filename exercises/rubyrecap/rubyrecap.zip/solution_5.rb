
5) How are the methods ending with exclamation mark different? You can explain on the following example:
str1 = "MY STRING"
str1.downcase
str1.downcase!

Uisng ! behind method makes it a permanent assignment. For example, in this case str1.downcase will create a downcase copy whereas str1.downcase! will downcase str1 permanently.
