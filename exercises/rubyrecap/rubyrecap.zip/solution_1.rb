1) Can you explain the ||= operator?
Example of use:
  a = 1
  b = 2
  a ||= b  (Hint! Same as: a = a || b)

One more example of use:
  c = nil
  d = 40
  c ||= d  (Hint! Same as: c = c || d)

Answer:
Conditional Assignments, if a is empty, assign the value to a, otherwise a retains its value