def celtofah(cel)
  fal = (cel * 1.8)+32
end

p celtofah(20)
